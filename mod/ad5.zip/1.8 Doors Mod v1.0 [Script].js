///* 1.8 Doors Mod v1.0 *///
///* By: @TaQuItO_988 *///

var notSetDoor = [6,27,30,31,32,37,38,39,40,50,53,54,58,59,60,61,62,63,64,65,66,67,68,71,78,81,83,85,92,96,101,102,104,105,106,107,108,109,114,120,127,128,139,141,142,156,171,175,183,184,185,186,187,188,189,198,200,201,202,203,204,205,206,207,208,209,245];
var allDoors = [200,201,202,203,204,205,206,207,208,209];
var doorsDrop = [427,427,428,428,429,429,430,430,431,431];
var openDoors = [201,203,205,207,209];
var closeDoors = [200,202,204,206,208];
var doorsItems = [427,428,429,430,431];
var side;

ModPE.setItem(427,"skull_creeper",0,"Sprouce Door",1);
Item.addShapedRecipe(427,1,0,["ww ","ww ","ww "],["w",5,1]);
ModPE.setItem(428,"skull_skeleton",0,"Birch Door",1);
Item.addShapedRecipe(428,1,0,["ww ","ww ","ww "],["w",5,2]);
ModPE.setItem(429,"skull_steve",0,"Jungle Door",1);
Item.addShapedRecipe(429,1,0,["ww ","ww ","ww "],["w",5,3]);
ModPE.setItem(430,"skull_wither",0,"Acacia Door",1);
Item.addShapedRecipe(430,1,0,["ww ","ww ","ww "],["w",5,4]);
ModPE.setItem(431,"skull_zombie",0,"Dark Oak Door",1);
Item.addShapedRecipe(431,1,0,["ww ","ww ","ww "],["w",5,5]);

Block.defineDoor = function(id1,id2,name,texture_upper,texture_lower){
Block.defineBlock(id1,name,[[texture_upper,0],[texture_upper,0],[texture_upper,0],[texture_upper,0],[texture_upper,0],[texture_upper,0],[texture_lower,0],["command_block",0],[texture_lower,0],[texture_lower,0],[texture_lower,0],[texture_lower,0]],0,false);
Block.defineBlock(id2,name,[[texture_upper,0],[texture_upper,0],[texture_upper,0],[texture_upper,0],[texture_upper,0],[texture_upper,0],[texture_lower,0],["command_block",0],[texture_lower,0],[texture_lower,0],[texture_lower,0],[texture_lower,0]],0,false);
Block.setShape(id1,0,0,0,1,1,3/16);
Block.setShape(id2,0,0,0,3/16,1,1);
Block.setLightOpacity(id1,0.2);
Block.setLightOpacity(id2,0.2);
Block.setRenderLayer(id1,5);
Block.setRenderLayer(id2,5);
Block.setExplosionResistance(id1,15);
Block.setExplosionResistance(id2,15);
Block.setDestroyTime(id1,0.3);
Block.setDestroyTime(id2,0.3);
}

function useItem(x,y,z,i,b,s){
openDoor(x,y,z,i,b);
if(notSetDoor.indexOf(getTile(x,y,z))==-1&&s==1&&doorsDrop.indexOf(i)!=-1){
Entity.setCarriedItem(Player.getEntity(),0,0,0);
Level.setDoor(x,y+1,z,i,b);
}}

Level.setDoor = function(x,y,z,i,b){
if(i==427&&side==1){
setTile(x,y+1,z,200,0);
setTile(x,y,z,200,1);
}
else if(i==427&&side==2){
setTile(x,y+1,z,201,0);
setTile(x,y,z,201,1);
}
else if(i==428&&side==1){
setTile(x,y+1,z,202,0);
setTile(x,y,z,202,1);
}
else if(i==428&&side==2){
setTile(x,y+1,z,203,0);
setTile(x,y,z,203,1);
}
else if(i==429&&side==1){
setTile(x,y+1,z,204,0);
setTile(x,y,z,204,1);
}
else if(i==429&&side==2){
setTile(x,y+1,z,205,0);
setTile(x,y,z,205,1);
}
else if(i==430&&side==1){
setTile(x,y+1,z,206,0);
setTile(x,y,z,206,1);
}
else if(i==430&&side==2){
setTile(x,y+1,z,207,0);
setTile(x,y,z,207,1);
}
else if(i==431&&side==1){
setTile(x,y+1,z,208,0);
setTile(x,y,z,208,1);
}
else if(i==431&&side==2){
setTile(x,y+1,z,209,0);
setTile(x,y,z,209,1);
}}

function openDoor(x,y,z,i,b){
if(openDoors.indexOf(b)!=-1&&Level.getData(x,y,z)==1){
setTile(x,y+1,z,closeDoors[openDoors.indexOf(b)],0);
setTile(x,y,z,closeDoors[openDoors.indexOf(b)],1);
Level.playSoundEnt(Player.getEntity(),"random.door_open",10);
}
else if(closeDoors.indexOf(b)!=-1&&Level.getData(x,y,z)==1){
setTile(x,y+1,z,openDoors[closeDoors.indexOf(b)],0);
setTile(x,y,z,openDoors[closeDoors.indexOf(b)],1);
Level.playSoundEnt(Player.getEntity(),"random.door_close",10);
}
else if(openDoors.indexOf(b)!=-1&&Level.getData(x,y,z)==0){
setTile(x,y,z,closeDoors[openDoors.indexOf(b)],0);
setTile(x,y-1,z,closeDoors[openDoors.indexOf(b)],1);
Level.playSoundEnt(Player.getEntity(),"random.door_open",10);
}
else if(closeDoors.indexOf(b)!=-1&&Level.getData(x,y,z)==0){
setTile(x,y,z,openDoors[closeDoors.indexOf(b)],0);
setTile(x,y-1,z,openDoors[closeDoors.indexOf(b)],1);
Level.playSoundEnt(Player.getEntity(),"random.door_close",10);
}}

function modTick(){
if(doorsItems.indexOf(Player.getCarriedItem())!=-1){
checkView();
}}

function checkView(){
yaw = Math.floor(Entity.getYaw(Player.getEntity()))%360;
if(yaw<=0){
Entity.setRot(Player.getEntity(),720,Entity.getPitch(Player.getEntity()));
}
if(yaw>225&&yaw<315){
side=2;
}
else if(yaw>315||yaw<45){
side=1;
}
else if(yaw>45&&yaw<135){
side=2;
}
else if(yaw>135&&yaw<225){
side=1;
}}

function destroyBlock(x,y,z){
if(Level.getGameMode()==0){
dropDoorItem(x,y,z);
}}

function dropDoorItem(x,y,z){
if(allDoors.indexOf(getTile(x,y,z))!=-1&&Level.getData(x,y,z)==0){
Level.dropItem(x+0.5,y-0.5,z+0.5,0,doorsDrop[allDoors.indexOf(getTile(x,y,z))],1,0);
Level.destroyBlock(x,y-1,z,false);
}
else if(allDoors.indexOf(getTile(x,y,z))!=-1&&Level.getData(x,y,z)==1){
Level.dropItem(x+0.5,y+0.5,z+0.5,0,doorsDrop[allDoors.indexOf(getTile(x,y,z))],1,0);
Level.destroyBlock(x,y+1,z,false);
}
else if(allDoors.indexOf(getTile(x,y+1,z))!=-1){
Level.dropItem(x+0.5,y+1.5,z+0.5,0,doorsDrop[allDoors.indexOf(getTile(x,y+1,z))],1,0);
Level.destroyBlock(x,y+1,z,false);
Level.destroyBlock(x,y+2,z,false);
}}

Block.defineDoor(200,201,"sprouce_door","cauldron_side","cauldron_top");
Block.defineDoor(202,203,"birch_door","cauldron_bottom","cauldron_inner");
Block.defineDoor(204,205,"jungle_door","dragon_egg","flower_pot");
Block.defineDoor(206,207,"acacia_door","jukebox_side","jukebox_top");
Block.defineDoor(208,209,"dark_oak_door","trip_wire","trip_wire_source");
